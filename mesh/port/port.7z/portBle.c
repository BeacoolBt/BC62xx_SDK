#include "common.h"

#include "portBle.h"
#include "co_com.h"
#include "math.h"
#include "bc62xx_ble.h"

#include "bc62xx_flash.h"
#include "flash_config.h"

/*
 * MACROS
 ****************************************************************************************
 */
#define GATT_MTU_SIZE	(196)
#define ADV_MAX_SIZE	(31)
#define ADV_HEAD_LEN	(3)
#define ADV_QUEUE_SIZE	(4)


/*
 * STRUCTURES
 ****************************************************************************************
 */

typedef struct
{
	uint8_t sAdvType;//adv type
	uint8_t len;//adv data length
	uint8_t data[ADV_MAX_SIZE];//adv data
	uint16_t itl;
	uint8_t nb;
}_adv_info_t;

typedef struct
{
	_adv_info_t advTx[ADV_QUEUE_SIZE];
	uint8_t busy:4;//0 idel; 1 busy
	uint8_t head:2;//
	uint8_t tail:2;
	SYS_TIMER_TYPE txTimer;
}_adv_send_t;


/*
 * PRIVATE VARIABLES
 ****************************************************************************************
 */
static SYS_TIMER_TYPE stAdvTimer;
static mesh_ble_event_callback bleCb = NULL;
const uint8_t ucAdvHeader[ADV_HEAD_LEN] = {2,1,2};// 02 01 02
static _adv_send_t *pstSendQueue;

/*
 * GLOBAL VARIABLE
 ****************************************************************************************
 */

/*
 * LOCAL FUNCTION
 ****************************************************************************************
 */
static uint8_t _adv_data_into_queue(uint8_t sAdvType, uint16_t itl, uint8_t nb, uint16_t len, const uint8_t* data)
{
	_adv_info_t* _tmp = &pstSendQueue->advTx[pstSendQueue->head];
	_tmp->sAdvType = sAdvType;
	_tmp->itl = itl;
	_tmp->nb = nb;
	_tmp->len = len;
	memcpy(_tmp->data, data, _tmp->len);
	
	if(++pstSendQueue->head == pstSendQueue->tail){
		pstSendQueue->tail++;
	}
	return 0;
}

static _adv_info_t* _adv_data_from_queue(void)
{
	if(pstSendQueue->head == pstSendQueue->tail)
		return NULL;
	return &pstSendQueue->advTx[pstSendQueue->tail++];
}

static uint8_t _adv_data_queue_init(void)
{
	pstSendQueue = ke_malloc(sizeof(_adv_send_t), 0);
	if(!pstSendQueue)
		return 1;
	memset(pstSendQueue, 0, sizeof(_adv_send_t));
	return 0;
}
static uint8_t _adv_data_queue_deinit(void)
{
	if(!pstSendQueue)
		return 1;

	ke_free(pstSendQueue);
	return 0;
}


/**
 ****************************************************************************************
 * @brief ble stack start and set event callback function
 *
 * @param[in] cb	callback function
 * return
 * [0]ble stack start success, [1]staet failed
 ****************************************************************************************
 */
uint32_t mesh_ble_start(mesh_ble_event_callback cb)
{
	M_PRINTF(L_AL, "");

	HWRITE(mem_le_scan_type, SCAN_TYPE_PASSIVE);//Set scan type: 
												//1.SCAN_TYPE_ACTIVE, both adv and scan response can be received;
												//2.SCAN_TYPE_PASSIVE, only can receive adv.
	bleCb = cb;

	_adv_data_queue_init();
	return 0;
}

/**
 ****************************************************************************************
 * @brief process ble event
 ****************************************************************************************
 */
void mesh_ble_process(void)
{
	//M_PRINTF(L_AL, "");
	IPC_DealSingleStep();
}


/**
 ****************************************************************************************
 * @brief stop ble stack and unset event callback function
 ****************************************************************************************
 */
void mesh_ble_stop()
{
	M_PRINTF(L_AL, "");
	_adv_data_queue_deinit();
}

uint32_t mesh_ble_event_set(MESH_BLE_EVENT ev, void* param)
{
	if(bleCb == NULL)
		return 0;
	return bleCb(ev, param);
}

/**
 ****************************************************************************************
 * @brief start non-connectable and non-scannable undirected advertising events
 ****************************************************************************************
 */
void adv_close_cb(int params)
{
	HWRITE(mem_le_adv_enable, 0x00);
	_adv_info_t* _data = _adv_data_from_queue();
	if(_data){
		M_PRINTF(L_AL, "Continue Send [%p] ADVType[%x]", _data, _data->sAdvType);
		HWRITE(mem_le_adv_type, _data->sAdvType);
		HW_REG_16BIT(reg_map(mem_le_adv_interval_max), _data->itl);
		memcpy((unsigned char*)reg_map(mem_le_adv_data), _data->data, _data->len);
		HWRITE(mem_le_adv_data_len, _data->len);
		HWRITE(mem_le_adv_enable, 0x01);
		//restart timer to close adv
		SYS_SetTimer(&stAdvTimer, (_data->nb+4)*(_data->itl>>4), TIMER_SINGLE, adv_close_cb);
		return;
	}
	M_PRINTF(L_AL, "Send Over");
	pstSendQueue->busy = 0;
}

void mesh_adv_data_send(uint16_t itl, uint8_t nb, uint16_t len, const uint8_t* data)
{
	M_PRINTF(L_AL, "itl[%x] nb[%x]", itl, nb);
	m_printf_hex(L_AL, "mesh adv data send", data, len);
#if 1
	if(pstSendQueue->busy == 1){
		_adv_data_into_queue(ADV_TYPE_NOCONNECT, itl, nb, len, data);
		return;
	}
	
	pstSendQueue->busy = 1;
	HWRITE(mem_le_adv_enable, 0x00);

	HWRITE(mem_le_adv_type, ADV_TYPE_NOCONNECT);
	HW_REG_16BIT(reg_map(mem_le_adv_interval_max), itl);
	memcpy((unsigned char*)reg_map(mem_le_adv_data),data,len);
	HWRITE(mem_le_adv_data_len,len);

	HWRITE(mem_le_adv_enable, 0x01);

	//start timer to close adv
	SYS_SetTimer(&stAdvTimer, (nb+4)*(itl>>4), TIMER_SINGLE, adv_close_cb);
#endif
}

/**
 ****************************************************************************************
 * @brief start connectable and scannable undirected advertising events
 ****************************************************************************************
 */
void mesh_con_adv_data_send(uint16_t itl, uint8_t nb, uint16_t len, const uint8_t* data)
{
#if 1
	if(len > ADV_MAX_SIZE-ADV_HEAD_LEN  || len <= 0 )
		return ;

	/*stop adv data send*/

	uint16_t _len = len + ADV_HEAD_LEN;
	uint8_t _data[ADV_MAX_SIZE] = {2,1,2};

	memcpy(_data+ADV_HEAD_LEN, data, len);
	M_PRINTF(L_AL, "itl[%x] nb[%x]", itl, nb);
	m_printf_hex(L_AL, "mesh con adv data send", _data, _len);

	if(pstSendQueue->busy == 1){
		_adv_data_into_queue(ADV_TYPE_NOMAL, itl, nb, _len, _data);
		return;
	}
	pstSendQueue->busy = 1;
	HWRITE(mem_le_adv_enable, 0x00);
	HWRITE(mem_le_adv_type, ADV_TYPE_NOMAL);
	HW_REG_16BIT(reg_map(mem_le_adv_interval_max), itl);
	memcpy((unsigned char*)reg_map(mem_le_adv_data),_data,_len);
	HWRITE(mem_le_adv_data_len,_len);

	HWRITE(mem_le_adv_enable, 0x01);
	SYS_SetTimer(&stAdvTimer, (nb+1)*(itl>>4), TIMER_SINGLE, adv_close_cb);
#endif	
}

/**
 ****************************************************************************************
 * @brief stop connectable adversting
 ****************************************************************************************
 */
void mesh_con_adv_stop(void)
{
	M_PRINTF(L_AL, "");
	HWRITE(mem_le_adv_enable, 0x00);
}

/**
 ****************************************************************************************
 * @brief disconnect ble connection
 *
 * @param[in] handle	need to closed connected handle 
 ****************************************************************************************
 */
void mesh_con_stop(uint16_t handle)
{
	M_PRINTF(L_AL, "");
	IPC_TxControlCmd(IPC_CMD_LE_DISCONNECT);
}

/**
****************************************************************************************
* @brief scan start function
****************************************************************************************
*/
void mesh_adv_scan_start(uint16_t itl)
{
	M_PRINTF(L_AL, "itl = 0x%02x", itl);
#if 1
	HW_REG_16BIT(reg_map(mem_le_scan_interval), itl);
	HW_REG_16BIT(reg_map(mem_le_scan_window), itl);
	HWRITE(mem_le_scan_enable,0x01);
#endif
}

/**
****************************************************************************************
* @brief scan stop function
****************************************************************************************
*/
void mesh_adv_scan_stop(void)
{
	M_PRINTF(L_AL, "");
	HWRITE(mem_le_scan_enable,0x00);
}

/**
****************************************************************************************
* @brief notify data function
handle: characteristic handle
data: value
len: length of packet to send
****************************************************************************************
*/
uint32_t mesh_con_notify(uint16_t handle, const uint8_t* data, uint32_t len)
{
	m_printf_hex(L_AL, "notify", data, len);
	M_PRINTF(L_AL, "HANDLE[%x]", handle);
	uint8_t BleSendData[GATT_MTU_SIZE+4]={0};
	uint8_t cnt;
	bool _advEnable = false;

	ASSERT_ERR(len>0 && len<=GATT_MTU_SIZE);
	
	IPC_DATA_FORMAT* temp = (IPC_DATA_FORMAT*)BleSendData;

	temp->ipctype =IPC_BLE_DATA;
	temp->len = len+2;
	temp->ipcUnion.uBleData.mhandle = handle;

	unsigned char *dataAy = (unsigned char *)&temp->ipcUnion.uBleData.data;

	for(cnt=0; cnt<len; cnt++){
		*(dataAy+cnt) = *(data+cnt);
	}
	/*Check Adv Started, if started, stop sendding adv*/
	if(HREAD(mem_le_adv_enable)){
		_advEnable = true;
		HWRITE(mem_le_adv_enable, 0x00);
	}
	
	IPC_TxPacket(temp);

	for(int i = 0; i < 65525; ++i){
		__asm__ __volatile__("nop");
	}
	/*if adv is started before, restart it*/
	if(_advEnable)
		HWRITE(mem_le_adv_enable, 0x01);
	return 0;
}
/**
****************************************************************************************
* @brief read confirm function
handle: characteristic handle
data: value
len: length of packet to send
****************************************************************************************
*/
uint32_t mesh_con_read_cfm(uint16_t handle, uint8_t* data, uint32_t len)
{
	M_PRINTF(L_AL, "");
	return 0;
}
/**
****************************************************************************************
* @brief write response function
handle: characteristic handle
****************************************************************************************
*/
uint8_t mesh_con_write_rsp(uint16_t handle)
{
	M_PRINTF(L_AL, "");
	return 0;
}

/**
****************************************************************************************
* @brief Get mtu size
****************************************************************************************
*/
uint32_t gattc_get_mtu(uint8_t conidx)
{
	M_PRINTF(L_AL, "");
	return GATT_MTU_SIZE;
}


uint8_t attm_reserve_handle_range(uint16_t* start_hdl, uint8_t nb_att)
{
	M_PRINTF(L_AL, "");
	//need dynamic allocation service
	return 0;
}

uint8_t attm_svc_create_db(uint16_t *shdl, uint16_t uuid, uint8_t *cfg_flag, uint8_t max_nb_att,
                           uint8_t *att_tbl, ke_task_id_t const dest_id,
                           const struct attm_desc *att_db, uint8_t svc_perm)
{
	M_PRINTF(L_AL, "");
	if(uuid == ATT_SVC_MESH_PROVISIONING){
		*shdl = GATT_PROV_START_HANDLE;
	}else if(uuid == ATT_SVC_MESH_PROXY){
		*shdl = GATT_PROXY_START_HANDLE;
	}
	
	return 0;
}
/**
****************************************************************************************
* @brief Control visibility of a service from peer device. service present in database
*		 but cannot be access by a peer device.
*
* @param[in] handle Service handle.
* @param[in] hide	True to hide the service, False to restore visibility
*
* @return Command status code:
*  - @ref ATT_ERR_NO_ERROR: If service allocation succeeds.
*  - @ref ATT_ERR_INVALID_HANDLE: If start_hdl given in parameter or UUIDs value invalid
****************************************************************************************
*/
uint8_t attmdb_svc_visibility_set(uint16_t handle, bool hide)
{
	M_PRINTF(L_AL, "HANDLE[%x] VAL[%x]", handle, hide);
	return 0;
#if 0
	int _iLen = mem_aes_input_len - mem_rc_att_list;
	uint8_t* _pucSerDat = (uint8_t*)reg_map(mem_rc_att_list);
	uint16_t _usHandle;
	//find hadle
	while(1){
		_usHandle = (_pucSerDat[1] << 8) + _pucSerDat[0];
		
		if(_usHandle == 0 || _usHandle > handle)
			return 1;
		
		if(_usHandle == handle){
			M_PRINTF(L_AL, "handle[%x]", _usHandle);
			if(hide){
				if(handle == GATT_PROV_START_HANDLE){
					_pucSerDat[6] = 0x13;
					_pucSerDat[7] = 0x2B;
				}
				else if(handle == GATT_PROXY_START_HANDLE){
					_pucSerDat[6] = 0x14;
					_pucSerDat[7] = 0x2B;
				}
				else{
					return 1;
				}
			}
			else{
				if(handle == GATT_PROV_START_HANDLE){
					_pucSerDat[6] = 0x27;
					_pucSerDat[7] = 0x18;
				}
				else if(handle == GATT_PROXY_START_HANDLE){
					_pucSerDat[6] = 0x28;
					_pucSerDat[7] = 0x18;
				}
				else{
					return 1;
				}
			}
			return 0;
		}
		_pucSerDat += 2 + _pucSerDat[2] + 1 + _pucSerDat[2+1+_pucSerDat[2]] + 1;
		
	}
#endif

	return 0;

}

/**
 ****************************************************************************************
 * @brief mac addres set
 *
 * @param[in] reversal	the mac bytes order.
 * @param[in] mac		six bytes mac data pointer
 *
 * @return status:
 *  - 0: If set success.
 *  - 1: If ser failed.
 ****************************************************************************************
 */
uint8_t mesh_mac_set(bool reversal, uint8_t* mac)
{
	uint8_t* addr = (uint8_t*)reg_map(mem_le_lap);
	if(memcmp(addr, mac, 6)){
		m_printf_hex(L_AL, "set mac", mac, 6);
		memcpy(addr, mac, 6);	
	}
	return 0;
}

/**
 ****************************************************************************************
 * @brief mac addres get
 *
 * @param[in] reversal	the mac bytes order.
 * @param[in] mac		six bytes mac data pointer
 *
 * @return status:
 *  - 0: If get success.
 *  - 1: If ger failed.
 ****************************************************************************************
 */
uint8_t mesh_mac_get(bool reversal, uint8_t* mac)
{
	M_PRINTF(L_AL, "");	
	memcpy(mac,(uint8_t*)reg_map(mem_le_lap),6);	
	return 0;
}

/**
 ****************************************************************************************
 * @brief flash read
 *
 * @param[in] addr		start addr.
 * @param[in] len		length of read data.
 * @param[out] data		read data buffer pointer.
 *
 * @return read data length:
 ****************************************************************************************
 */
uint32_t mesh_flash_read(uint32_t addr, uint32_t len, uint8_t* data)
{
	M_PRINTF(L_AL, "addr=%08x", addr);
	ASSERT_ERR(((addr+len)&PAGE_MASK) == ((addr)&PAGE_MASK));
	
	QSPI_Init();
	
	QSPI_ReadFlashData(addr,len,data);
	m_printf_hex(L_AL, "read end", data, len);
	return 0;
}

/**
 ****************************************************************************************
 * @brief flash erase and write
 *
 * @param[in] addr		start addr.
 * @param[in] len		length of write data.
 * @param[out] data		witer data buffer pointer.
 *
 * @return write data length:
 ****************************************************************************************
 */
uint32_t mesh_flash_write(uint32_t addr, uint32_t len, uint8_t* data)
{
	M_PRINTF(L_AL, "addr = %08x", addr);
	m_printf_hex(L_AL, "write data", data, len);

	ASSERT_ERR(len <= BUFF_SIZE && (addr&(PAGE_SIZE-1))==0);
	QSPI_Init();
	
	QSPI_PageEraseFlash(addr);
	QSPI_WriteFlashData(addr,len,data);
	M_PRINTF(L_AL, "write end");
	return 0;
}

uint32_t mesh_flash_write_nerase(uint32_t addr, uint32_t len, uint8_t* data)
{
	M_PRINTF(L_AL, "addr = %08x", addr);
	m_printf_hex(L_AL, "write data", data, len);
	
	ASSERT_ERR(((addr+len)&PAGE_MASK) == ((addr)&PAGE_MASK));
	
	QSPI_Init();
	QSPI_WriteFlashData(addr,len,data);
	return 0;
}

uint32_t mesh_flash_erase(uint32_t addr)
{
	M_PRINTF(L_AL, "erase data addr=0x%08x", addr);
	ASSERT_ERR((addr&(PAGE_SIZE-1))== 0);
	QSPI_Init();
	QSPI_PageEraseFlash(addr);
	return 0;
}

